/*
 * File:
 * Author:
 * Description:
 */

#ifndef HEADER_FILE
#define HEADER_FILE

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "global_defines.h"
#include "global_structs.h"
#include "global_variables.h"

#include "general_gets.h"

/*
#include "function_list_airports.h"
#include "function_add_or_list_flights.h"
#include "function_increase_date.h"
#include "function_list_departure_flights.h"
#include "function_list_arrival_flights.h"*/

#endif