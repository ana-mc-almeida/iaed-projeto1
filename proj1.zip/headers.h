/*
 * File:
 * Author:
 * Description:
 */

#ifndef HEADER_FILE
#define HEADER_FILE

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "global_defines.h"
#include "global_structs.h"
#include "global_variables.h"

#include "general_gets.h"

#endif