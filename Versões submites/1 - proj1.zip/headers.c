/*
 * File:
 * Author:
 * Description:
 */

#ifndef HEADER_FILE
#define HEADER_FILE

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "global_defines.c"
#include "global_structs.c"
#include "global_variables.c"

#include "general_gets.c"

#endif